
from lwbgt import Input, calculate

weather = Input(
    year=2024,
    month=4,
    day=15,
    hour=14,
    minute=30,
    gmt_offset_hours=5,  # Whole-hour offset required by this API
    averaging_minutes=60,
    urban=1,
    latitude_deg_north=18.5204,
    longitude_deg_east=73.8567,
    solar_w_m2=742.0,
    pressure_hpa=1008.4,
    air_temperature_c=32.1,
    relative_humidity_percent=68.0,
    wind_speed_m_s=2.8,
    wind_height_m=10.0,
    vertical_temperature_difference_c=1,
)

result = calculate(weather)

print("Calculation status:", result.status)

if result.status == 0:
    print(f"Estimated WBGT: {result.wbgt_c:.2f} °C")
else:
    print("WBGT calculation failed.")

if result.status != 0:
    print("Calculation failed; inspect the inputs.")
