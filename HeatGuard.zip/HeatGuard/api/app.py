
from pathlib import Path

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import numpy as np
from lwbgt import Input as WBGTInput, calculate as calculate_wbgt

app = FastAPI(
    title="HeatGuard API",
    description="API for AI-assisted personalized heat-risk prediction.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)

MODEL_PATH = (
    Path(__file__).resolve().parent.parent
    / "models"
    / "heatguard_logistic_regression.pkl"
)

model = joblib.load(MODEL_PATH)

class HeatRiskInput(BaseModel):
    city: str
    air_temp_c: float
    rh_pct: float = Field(ge=0, le=100)
    wind_kmh: float = Field(ge=0)
    solar_wm2: float | None = Field(default=None, ge=0)
    rain_last_24h_mm: float = Field(ge=0)
    pm25_ugm3: float = Field(ge=0)
    ozone_ppb: float = Field(ge=0)
    no2_ppb: float = Field(ge=0)
    night_min_c: float
    estimated_wbgt: float
    cumulative_heat_3d: float = Field(ge=0)
    age: float = Field(ge=0, le=120)
    gender: str
    pregnant: int = Field(ge=0, le=1)
    chronic_condition: int = Field(ge=0, le=1)
    heart_disease: int = Field(ge=0, le=1)
    diabetes: int = Field(ge=0, le=1)
    ckd: int = Field(ge=0, le=1)
    diuretic: int = Field(ge=0, le=1)
    beta_blocker: int = Field(ge=0, le=1)
    outdoor_work: int = Field(ge=0, le=1)
    exertion_level: str
    hydration_score: float | None = Field(default=None, ge=0, le=1)
    acclimatized: int = Field(ge=0, le=1)
    headache: int = Field(ge=0, le=1)
    dizziness: int = Field(ge=0, le=1)
    nausea: int = Field(ge=0, le=1)
    wbgt_mean_v2_c: float
    wbgt_max_v2_c: float
    wbgt_min_v2_c: float
    temperature_max_v2_c: float
    shortwave_mean_v2_wm2: float
    shortwave_max_v2_wm2: float
    elevation_v2_m: float
    
class WBGTRequest(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    local_time: datetime
    timezone_name: str
    air_temp_c: float
    rh_pct: float = Field(ge=0, le=100)
    wind_kmh: float = Field(ge=0)
    solar_wm2: float = Field(ge=0)
    pressure_hpa: float = Field(default=1013.25, gt=0)
    urban: int = Field(default=1, ge=0, le=1)


@app.get("/")
def home():
    return {
        "message": "HeatGuard API is running",
        "status": "healthy",
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "model_loaded": model is not None,
    }



@app.post("/predict")
def predict(data: HeatRiskInput):
    try:
        input_df = pd.DataFrame([data.model_dump()])

        # Keep the existing prediction calculation.
        risk_score = float(model.predict_proba(input_df)[0][1])

        if risk_score < 0.30:
            risk_level = "Low"
        elif risk_score < 0.60:
            risk_level = "Moderate"
        else:
            risk_level = "High"

        top_factors = []

        # Explain the prediction for a fitted scikit-learn Pipeline
        # whose final estimator is binary Logistic Regression.
        if hasattr(model, "named_steps") and len(model.steps) >= 2:
            classifier = model.steps[-1][1]

            if (
                hasattr(classifier, "coef_")
                and classifier.coef_.shape[0] == 1
            ):
                # Apply every preprocessing step before the classifier.
                transformed = model[:-1].transform(input_df)
                transformed = np.asarray(transformed).reshape(-1)

                coefficients = classifier.coef_[0]
                feature_names = list(input_df.columns)

                if len(feature_names) == len(coefficients):
                    contributions = transformed * coefficients

                    readable_names = {
                        "estimated_wbgt": "Estimated WBGT",
                        "air_temp_c": "Air temperature",
                        "rh_pct": "Relative humidity",
                        "wind_kmh": "Wind speed",
                        "solar_wm2": "Solar radiation",
                        "night_min_c": "Night minimum temperature",
                        "cumulative_heat_3d": "Cumulative heat exposure",
                        "age": "Age",
                        "hydration_score": "Hydration score",
                        "exertion_level": "Exertion level",
                        "outdoor_work": "Outdoor work",
                        "acclimatized": "Heat acclimatization",
                        "chronic_condition": "Chronic condition",
                        "pregnant": "Pregnancy",
                    }

                    ranked = sorted(
                        zip(feature_names, contributions),
                        key=lambda item: abs(float(item[1])),
                        reverse=True,
                    )

                    for feature, contribution in ranked[:6]:
                        contribution = float(contribution)

                        top_factors.append({
                            "feature": readable_names.get(
                                feature, feature.replace("_", " ").title()
                            ),
                            "contribution": round(contribution, 4),
                            "direction": (
                                "increases_risk"
                                if contribution > 0
                                else "decreases_risk"
                                if contribution < 0
                                else "neutral"
                            ),
                            "explanation": (
                                "Pushes the model prediction toward higher risk."
                                if contribution > 0
                                else "Pushes the model prediction toward lower risk."
                                if contribution < 0
                                else "Has no contribution to the model's log-odds."
                            ),
                        })

        return {
            "estimated_risk_score": round(risk_score * 100, 2),
            "risk_level": risk_level,
            "disclaimer": (
                "Experimental model output, not a clinical diagnosis "
                "or validated medical risk assessment."
            ),
            "top_factors": top_factors,
            "explanation_method": (
                "Logistic Regression coefficient contributions "
                "in log-odds space"
            ),
        }

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(exc)}",
        ) from exc

@app.post("/calculate-wbgt")
def calculate_wbgt_endpoint(data: WBGTRequest):
    try:
        local_time = data.local_time.replace(tzinfo=None)

        # Interpret the supplied timestamp in its named timezone.
        local_zone = ZoneInfo(data.timezone_name)
        local_time = local_time.replace(tzinfo=local_zone)

        # Convert to UTC so the library can use its supported
        # whole-hour offset without misrepresenting India time.
        utc_time = local_time.astimezone(timezone.utc)

        wbgt_input = WBGTInput(
            year=utc_time.year,
            month=utc_time.month,
            day=utc_time.day,
            hour=utc_time.hour,
            minute=utc_time.minute,
            gmt_offset_hours=0,
            averaging_minutes=60,
            urban=data.urban,
            latitude_deg_north=data.latitude,
            longitude_deg_east=data.longitude,
            solar_w_m2=data.solar_wm2,
            pressure_hpa=data.pressure_hpa,
            air_temperature_c=data.air_temp_c,
            relative_humidity_percent=data.rh_pct,
            wind_speed_m_s=data.wind_kmh / 3.6,
            wind_height_m=10.0,
            vertical_temperature_difference_c=1.0,
        )

        result = calculate_wbgt(wbgt_input)

        if result.status != 0:
            raise HTTPException(
                status_code=422,
                detail="WBGT calculation did not succeed.",
            )

        return {
            "status": result.status,
            "wbgt_c": round(result.wbgt_c, 2),
            "natural_wet_bulb_c": round(result.natural_wet_bulb_c, 2),
            "globe_temperature_c": round(result.globe_temperature_c, 2),
            "psychrometric_wet_bulb_c": round(
                result.psychrometric_wet_bulb_c, 2
            ),
            "disclaimer": (
                "WBGT is an environmental heat-stress estimate. "
                "It is not an individual medical-risk assessment."
            ),
        }

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=422,
            detail=f"WBGT calculation failed: {str(exc)}",
        ) from exc
import httpx
from fastapi import HTTPException, Query

@app.get("/reverse-geocode")
async def reverse_geocode(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180),
):
    url = "https://nominatim.openstreetmap.org/reverse"

    params = {
        "lat": latitude,
        "lon": longitude,
        "format": "jsonv2",
        "addressdetails": 1,
        "zoom": 10,
    }

    headers = {
        "User-Agent": "HeatGuard/1.0"
    }

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                url,
                params=params,
                headers=headers,
            )
            response.raise_for_status()
            data = response.json()

        address = data.get("address", {})

        city = (
            address.get("city")
            or address.get("town")
            or address.get("village")
            or address.get("municipality")
            or address.get("county")
        )

        return {
            "city": city,
            "region": address.get("state"),
            "country": address.get("country"),
        }

    except httpx.HTTPError as exc:
        print(f"Reverse geocoding failed: {exc}")
        raise HTTPException(
            status_code=502,
            detail="Reverse geocoding service is unavailable.",
        ) from exc