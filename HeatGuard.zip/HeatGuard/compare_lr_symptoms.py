
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    classification_report,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DATA_PATH = Path("outputs/heatguard_cleaned.csv")
SYMPTOM_FEATURES = ["headache", "dizziness", "nausea"]

df = pd.read_csv(DATA_PATH)

target = "heat_event_risk"
groups = df["patient_day_id"]
X = df.drop(columns=["patient_day_id", "date", target])
y = df[target].astype(int)

# Use the same group-aware split as the original notebook.
splitter = GroupShuffleSplit(
    n_splits=1, test_size=0.20, random_state=42
)
train_idx, test_idx = next(splitter.split(X, y, groups=groups))

X_train, X_test = X.iloc[train_idx].copy(), X.iloc[test_idx].copy()
y_train, y_test = y.iloc[train_idx].copy(), y.iloc[test_idx].copy()

print("Dataset:", df.shape)
print("Training records:", len(X_train))
print("Test records:", len(X_test))
print("Training positives:", int(y_train.sum()))
print("Test positives:", int(y_test.sum()))
print("Shared patient-day IDs:",
      len(set(groups.iloc[train_idx]) & set(groups.iloc[test_idx])))


def evaluate(label, drop_symptoms):
    train_x = X_train.drop(columns=drop_symptoms, errors="ignore")
    test_x = X_test.drop(columns=drop_symptoms, errors="ignore")

    numeric_features = train_x.select_dtypes(
        include=["number", "bool"]
    ).columns.tolist()
    categorical_features = [
        col for col in train_x.columns
        if col not in numeric_features
    ]

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer([
        ("numeric", numeric_pipeline, numeric_features),
        ("categorical", categorical_pipeline, categorical_features),
    ])

    model = Pipeline([
        ("preprocessor", preprocessor),
        ("classifier", LogisticRegression(
            class_weight="balanced",
            max_iter=2000,
            random_state=42,
        )),
    ])

    model.fit(train_x, y_train)
    predictions = model.predict(test_x)
    probabilities = model.predict_proba(test_x)[:, 1]

    print(f"\n{'=' * 55}")
    print(label)
    print("=" * 55)
    print(classification_report(
        y_test, predictions,
        labels=[0, 1],
        target_names=["No heat-risk event", "Heat-risk event"],
        zero_division=0,
    ))
    print("Confusion matrix [[TN, FP], [FN, TP]]:")
    print(confusion_matrix(y_test, predictions, labels=[0, 1]))
    print("ROC-AUC:", round(roc_auc_score(y_test, probabilities), 4))
    print("PR-AUC (Average Precision):",
          round(average_precision_score(y_test, probabilities), 4))


evaluate("A — WITH SYMPTOMS", [])
evaluate("B — WITHOUT SYMPTOMS", SYMPTOM_FEATURES)
